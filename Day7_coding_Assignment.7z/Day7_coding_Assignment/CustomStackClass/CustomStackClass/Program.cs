﻿using System;
using System.Collections.Generic;

public class MyStack<T>
{
    private List<T> _stack;

    public MyStack()
    {
        _stack = new List<T>();
    }

    // Method to get the count of items in the stack
    public int Count()
    {
        return _stack.Count;
    }

    // Method to pop an item from the stack
    public T Pop()
    {
        if (_stack.Count == 0)
        {
            throw new InvalidOperationException("The stack is empty.");
        }

        T item = _stack[_stack.Count - 1];
        _stack.RemoveAt(_stack.Count - 1);
        return item;
    }

    // Method to push an item onto the stack
    public void Push(T item)
    {
        _stack.Add(item);
    }
}

public class Program
{
    public static void Main()
    {
        MyStack<int> intStack = new MyStack<int>();
        intStack.Push(1);
        intStack.Push(2);
        intStack.Push(3);

        Console.WriteLine(intStack.Count()); // Output: 3
        Console.WriteLine(intStack.Pop());   // Output: 3
        Console.WriteLine(intStack.Count()); // Output: 2

        MyStack<string> stringStack = new MyStack<string>();
        stringStack.Push("Hello");
        stringStack.Push("World");

        Console.WriteLine(stringStack.Count()); // Output: 2
        Console.WriteLine(stringStack.Pop());   // Output: World
        Console.WriteLine(stringStack.Count()); // Output: 1
    }
}