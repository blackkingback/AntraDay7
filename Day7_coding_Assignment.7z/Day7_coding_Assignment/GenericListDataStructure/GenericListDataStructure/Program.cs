﻿using System;
using System.Collections.Generic;

public class MyList<T>
{
    private List<T> _list;

    public MyList()
    {
        _list = new List<T>();
    }

    // Method to add an element to the list
    public void Add(T element)
    {
        _list.Add(element);
    }

    // Method to remove an element at a specific index and return it
    public T Remove(int index)
    {
        if (index < 0 || index >= _list.Count)
        {
            throw new ArgumentOutOfRangeException("Index is out of range.");
        }

        T element = _list[index];
        _list.RemoveAt(index);
        return element;
    }

    // Method to check if the list contains a specific element
    public bool Contains(T element)
    {
        return _list.Contains(element);
    }

    // Method to clear all elements from the list
    public void Clear()
    {
        _list.Clear();
    }

    // Method to insert an element at a specific index
    public void InsertAt(T element, int index)
    {
        if (index < 0 || index > _list.Count)
        {
            throw new ArgumentOutOfRangeException("Index is out of range.");
        }

        _list.Insert(index, element);
    }

    // Method to delete an element at a specific index
    public void DeleteAt(int index)
    {
        if (index < 0 || index >= _list.Count)
        {
            throw new ArgumentOutOfRangeException("Index is out of range.");
        }

        _list.RemoveAt(index);
    }

    // Method to find an element at a specific index
    public T Find(int index)
    {
        if (index < 0 || index >= _list.Count)
        {
            throw new ArgumentOutOfRangeException("Index is out of range.");
        }

        return _list[index];
    }
}

public class Program
{
    public static void Main()
    {
        MyList<int> intList = new MyList<int>();
        intList.Add(1);
        intList.Add(2);
        intList.Add(3);

        Console.WriteLine(intList.Contains(2)); // Output: True
        Console.WriteLine(intList.Remove(1));   // Output: 2
        Console.WriteLine(intList.Contains(2)); // Output: False

        intList.InsertAt(4, 1);
        Console.WriteLine(intList.Find(1));     // Output: 4

        intList.DeleteAt(1);
        Console.WriteLine(intList.Contains(4)); // Output: False

        intList.Clear();
        Console.WriteLine(intList.Contains(1)); // Output: False

        MyList<string> stringList = new MyList<string>();
        stringList.Add("Hello");
        stringList.Add("World");

        Console.WriteLine(stringList.Find(0));  // Output: Hello
    }
}
