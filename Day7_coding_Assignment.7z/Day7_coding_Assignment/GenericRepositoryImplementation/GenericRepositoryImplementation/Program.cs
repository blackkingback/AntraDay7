﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Entity
{
    public int Id { get; set; }
}



public interface IRepository<T> where T : Entity
{
    void Add(T item);
    void Remove(T item);
    void Save();
    IEnumerable<T> GetAll();
    T GetById(int id);
}

public class GenericRepository<T> : IRepository<T> where T : Entity
{
    private readonly List<T> _context;

    public GenericRepository()
    {
        _context = new List<T>();
    }

    public void Add(T item)
    {
        if (item == null)
        {
            throw new ArgumentNullException(nameof(item));
        }

        _context.Add(item);
    }

    public void Remove(T item)
    {
        if (item == null)
        {
            throw new ArgumentNullException(nameof(item));
        }

        _context.Remove(item);
    }

    public void Save()
    {
        // In a real-world scenario, this method would persist changes to the database.
        // For this in-memory example, we don't need to do anything.
    }

    public IEnumerable<T> GetAll()
    {
        return _context;
    }

    public T GetById(int id)
    {
        return _context.FirstOrDefault(e => e.Id == id);
    }
}

public class Customer : Entity
{
    public string Name { get; set; }
}

public class Program
{
    public static void Main()
    {
        IRepository<Customer> customerRepository = new GenericRepository<Customer>();

        var customer1 = new Customer { Id = 1, Name = "John Doe" };
        var customer2 = new Customer { Id = 2, Name = "Jane Smith" };

        customerRepository.Add(customer1);
        customerRepository.Add(customer2);

        customerRepository.Save();

        IEnumerable<Customer> customers = customerRepository.GetAll();
        foreach (var customer in customers)
        {
            Console.WriteLine($"Customer ID: {customer.Id}, Name: {customer.Name}");
        }

        var customerById = customerRepository.GetById(1);
        Console.WriteLine($"Customer found by ID 1: Name = {customerById.Name}");

        customerRepository.Remove(customer1);
        customerRepository.Save();

        customers = customerRepository.GetAll();
        Console.WriteLine("Customers after removal:");
        foreach (var customer in customers)
        {
            Console.WriteLine($"Customer ID: {customer.Id}, Name: {customer.Name}");
        }
    }
}